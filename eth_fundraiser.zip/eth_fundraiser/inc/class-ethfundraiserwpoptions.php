<?php
/**
 * This is the admin form.
 *
 * @package options
 */

/**
 * EthFundraiserWPOptions
 */
class EthFundraiserWPOptions {

	/**
	 * Menu Slug.
	 *
	 * @var $menu_slug
	 */
	private $menu_slug;

	/**
	 * Options.
	 *
	 * @var $options.
	 */
	private $options;

	/**
	 * Notice for success or error.
	 *
	 * @var $notices
	 */
	public $notices = array(
		'ok' => array(),
		'error' => array(),
	);

	/**
	 * Constructor
	 */
	public function __construct() {

		$this->menu_slug = 'eth_fundraiser-options-page';

		$this->options = array(
			'eth_fundraiser_address' => array(
				'type' => 'text',
				'sanitize' => 'text',
				'label' => __( 'Ethereum Address', 'eth_fundraiser' ),
				'description' => __( 'Use your ethereum address to use the component to send funds to your address.', 'eth_fundraiser' ),
			),
			'eth_fundraiser_banner' => array(
				'type' => 'select',
				'sanitize' => 'text',
				'label' => __( 'Banner Position', 'eth_fundraiser' ),
				'default' => 'none',
				'options' => array(
					'none' => __( 'None', 'eth_fundraiser' ),
					'left' => __( 'Left', 'eth_fundraiser' ),
					'center' => __( 'Center', 'eth_fundraiser' ),
					'right' => __( 'Right', 'eth_fundraiser' ),
				),
				'description' => __( 'Select a position for the banner to appear.', 'eth_fundraiser' ),
			),
			'eth_fundraiser_title' => array(
				'type' => 'text',
				'sanitize' => 'text',
				'label' => __( 'Banner Text', 'eth_fundraiser' ),
				'description' => __( 'Change the banner title text.', 'eth_fundraiser' ),
				'default' => 'Buy us a coffee.',
			),
			'eth_fundraiser_title_color' => array(
				'type' => 'text',
				'sanitize' => 'hex_color',
				'label' => __( 'Banner Color Text', 'eth_fundraiser' ),
				'description' => __( 'Change the banner title color text.' ),
				'default' => '#000000',
			),
			'eth_fundraiser_svg_circle' => array(
				'type' => 'text',
				'sanitize' => 'hex_color',
				'label' => __( 'SVG Circle Background', 'eth_fundraiser' ),
				'description' => __( 'Change the circle background color', 'eth_fundraiser' ),
				'default' => '#14044d',
			),
			'eth_fundraiser_svg_eth_icon' => array(
				'type' => 'text',
				'sanitize' => 'hex_color',
				'label' => __( 'SVG Eth Icon', 'eth_fundraiser' ),
				'description' => __( 'Change the circle background color', 'eth_fundraiser' ),
				'default' => '#ffffff',
			),
			'eth_fundraiser_banner_background' => array(
				'type' => 'text',
				'sanitize' => 'hex_color',
				'label' => __( 'Banner Background', 'eth_fundraiser' ),
				'description' => __( 'Change the banner background', 'eth_fundraiser' ),
				'default' => '#ffffff',
			),
			'eth_fundraiser_button_background' => array(
				'type' => 'text',
				'sanitize' => 'hex_color',
				'label' => __( 'Button Background', 'eth_fundraiser' ),
				'description' => __( 'Change the button background', 'eth_fundraiser' ),
				'default' => '#14044d',
			),
			'eth_fundraiser_button_text' => array(
				'type' => 'text',
				'sanitize' => 'hex_color',
				'label' => __( 'Button Text Color', 'eth_fundraiser' ),
				'description' => __( 'Change the button text color.', 'eth_fundraiser' ),
				'default' => '#ffffff',
			),

			'eth_fundraiser_eth_price_color' => array(
				'type' => 'text',
				'sanitize' => 'hex_color',
				'label' => __( 'Eth Price Color', 'eth_fundraiser' ),
				'description' => __( 'Change eth price text color.', 'eth_fundraiser' ),
				'default' => '#000000',
			),

			'eth_fundraiser_close_btn_color' => array(
				'type' => 'text',
				'sanitize' => 'hex_color',
				'label' => __( 'Close Button Color', 'eth_fundraiser' ),
				'description' => __( 'Change the close button color.', 'eth_fundraiser' ),
				'default' => '#808080',
			),
		);

		add_action( 'admin_menu', array( $this, 'create_options_menu_page' ) );
		add_action( 'admin_init', array( $this, 'save_options' ) );
	}

	/**
	 * Register the Options Menu
	 */
	public function create_options_menu_page() {
		add_menu_page(
			'Eth Fundraiser',
			'Eth Fundraiser',
			'manage_options',
			$this->menu_slug,
			array( $this, 'create_options_page_render' ),
			ETH_FUNDRAISER_URL . '/assets/img/eth_fundraiser.svg'
		);
	}


	/**
	 * Save the options submitted
	 */
	public function save_options() {
		if ( !isset( $_GET['page'] ) || $_GET['page'] != $this->menu_slug)
			return;

		if ( empty( $_POST ) )
			return;

		$any_saved = $this->import_options();

		foreach ( $this->options as $key => $atts ) {

			if ( 'import_code' == $atts['type'] )
				continue;

			if ( isset( $_POST[$key] ) ) {

				$value = $_POST[$key];
				// wp_send_json_success([$atts, $key]);
				if ( 'text' == $atts['sanitize'] ) {
					$value = sanitize_text_field($value);
				}

				if ('hex_color' == $atts['sanitize']) {
					$value = sanitize_hex_color($value);
					if(!isset($value)) {
						$any_saved = false;
						$this->notices['error'][] = __( 'Field ' . $atts['label'] . ' is invalid', 'eth_fundraiser' );
						return;
					}
				}

				if ( get_option( $key, '' ) != $value ) {
					update_option( $key, $value );
					$any_saved = true;

				}
			} elseif ( $atts['type'] == 'true' ) {
				update_option( $key, '0' );
				$any_saved = true;

			}
		}

		if ( $any_saved )
			$this->notices['ok'][] = __( 'Saved!', 'eth_fundraiser' );
	}

	/**
	 * Import Options
	 */
	public function import_options() {

		if ( isset( $_POST['import_code'] ) && !empty( $_POST['import_code'] ) ) {

			$sent_data = str_replace( '\"', '"', esc_html($_POST['import_code']) );

			$_POST['eth_fundraiser_address'] = '';
			if ( ( $start = strpos( $sent_data, 'eth_fundraiser_address = "' ) ) !== false ) {
				$start += 25;
				if ( ( $end = strpos( $sent_data, '"', $start ) ) !== false ) {
					$value = intval( substr( $sent_data, $start, $end - $start ) );
					if ( $value > 0 ) {
						$_POST['eth_fundraiser_address'] = sanitize_text_field( $value );
					}
				}
			}

			$_POST['eth_fundraiser_banner_background'] = '';
			if ( ( $start = strpos( $sent_data, 'eth_fundraiser_banner_background = "' ) ) !== false ) {
				$start += 30;
				if ( ( $end = strpos( $sent_data, '"', $start) ) !== false ) {
					$value = substr( $sent_data, $start, $end - $start );

					$_POST['eth_fundraiser_banner_background'] = sanitize_hex_color( $value );
				}
			}

			$_POST['eth_fundraiser_title'] = '';
			if ( ( $start = strpos( $sent_data, 'eth_fundraiser_title = "' ) ) !== false ) {
				$start += 30;
				if ( ( $end = strpos( $sent_data, '"', $start ) ) !== false ) {
					$value = intval( substr( $sent_data, $start, $end - $start ) );

					$_POST['eth_fundraiser_title'] = sanitize_text_field( $value );
				}
			}

			$_POST['eth_fundraiser_title_color'] = '';
			if ( ( $start = strpos( $sent_data, 'eth_fundraiser_title_color = "' ) ) !== false ) {
				$start += 30;
				if ( ( $end = strpos( $sent_data, '"', $start ) ) !== false ) {
					$value = intval( substr( $sent_data, $start, $end - $start ) );

					$_POST['eth_fundraiser_title_color'] = sanitize_hex_color( $value );
				}
			}

			$_POST['eth_fundraiser_svg_circle'] = '';
			if ( ( $start = strpos( $sent_data, 'eth_fundraiser_svg_circle = "' ) ) !== false ) {
				$start += 30;
				if ( ( $end = strpos( $sent_data, '"', $start ) ) !== false ) {
					$value = intval( substr( $sent_data, $start, $end - $start ) );

					$_POST['eth_fundraiser_svg_circle'] = sanitize_hex_color( $value );
				}
			}

			$_POST['eth_fundraiser_svg_eth_icon'] = '';
			if ( ( $start = strpos( $sent_data, 'eth_fundraiser_svg_eth_icon = "' ) ) !== false ) {
				$start += 30;
				if ( ( $end = strpos( $sent_data, '"', $start ) ) !== false ) {
					$value = intval( substr( $sent_data, $start, $end - $start ) );

					$_POST['eth_fundraiser_svg_eth_icon'] = sanitize_hex_color( $value );
				}
			}

			$_POST['eth_fundraiser_banner_background'] = '';
			if ( ( $start = strpos( $sent_data, 'eth_fundraiser_banner_background = "' ) ) !== false ) {
				$start += 30;
				if ( ( $end = strpos( $sent_data, '"', $start ) ) !== false ) {
					$value = intval( substr( $sent_data, $start, $end - $start ) );

					$_POST['eth_fundraiser_banner_background'] = sanitize_hex_color( $value );
				}
			}

			$_POST['eth_fundraiser_button_background'] = '';
			if ( ( $start = strpos( $sent_data, 'eth_fundraiser_button_background = "' ) ) !== false ) {
				$start += 30;
				if ( ( $end = strpos( $sent_data, '"', $start ) ) !== false ) {
					$value = intval( substr( $sent_data, $start, $end - $start ) );

					$_POST['eth_fundraiser_button_background'] = sanitize_hex_color( $value );
				}
			}

			$_POST['eth_fundraiser_close_btn_color'] = '';
			if ( ( $start = strpos( $sent_data, 'eth_fundraiser_close_btn_color = "' ) ) !== false ) {
				$start += 30;
				if (($end = strpos( $sent_data, '"', $start ) ) !== false ) {
					$value = intval( substr( $sent_data, $start, $end - $start ) );

					$_POST['eth_fundraiser_close_btn_color'] = sanitize_hex_color( $value );
				}
			}

			$_POST['eth_fundraiser_eth_price_color'] = '';
			if ( ( $start = strpos( $sent_data, 'eth_fundraiser_eth_price_color = "' ) ) !== false ) {
				$start += 30;
				if ( ( $end = strpos( $sent_data, '"', $start ) ) !== false ) {
					$value = intval( substr( $sent_data, $start, $end - $start ) );

					$_POST['eth_fundraiser_eth_price_color'] = sanitize_hex_color( $value );
				}
			}

			return true;
		}

		return false;
	}


	/**
	 * Render the output of admin page
	 */
	public function create_options_page_render() {

		?>
		<div class="wrap">
			<h1><?php esc_html_e( 'Eth Fundraiser Options', 'eth_fundraiser' ); ?></h1>

			<style>
				.btn-martelus-club {
					background: rgb(234, 33, 217);
					padding: 1rem;
					font-size: 15px;
					color: white;
					text-decorator:none !important;
					transition: 500ms;
				}
				.btn-martelus-club:link {
					text-decoration: none;
				}

				.btn-martelus-io {
					background: #039be5;
					padding: 1rem;
					font-size: 15px;
					color: white;
					text-decorator:none !important;
					transition: 500ms;
				}
				.btn-martelus-io:link {
					text-decoration: none;
				}
				.btn-group {
					margin: 3em 0;
				}

				.welcome-message {
					margin-top: 1em;
				}

				.btn-martelus-club:hover {
					background: rgb(255, 98, 242);
					color: rgb(255, 255, 255);
				}

				.btn-martelus-io:hover {
					background: #4abef8;
					color: #fff;
				}


			</style>
						
			<div class="btn-group">
				<a href="https://martelus.club" target="_blank" class="btn-martelus-club">Get Club Access</a>
				<a href="https://martelus.net" target="_blank" class="btn-martelus-io">Create an Account</a> 
			</div>
			<p class="welcome-message">
				The Eth Fundraiser Plugin allows you to raise funds through the ethereum blockchain. It also allows you to customize the component to match your site theme.<br>
				If you find that you need additional functionality there is a club member version available which offers multiple currencies, chain selection, token selection, additional wallet detection, installation assistance, technical support and more.
			</p>

			<?php
			if ( ! empty( $this->notices['ok'] ) ) {
				foreach ( $this->notices['ok'] as $ok ) {
					?>
					<div class="notice notice-success is-dismissible">
						<p><?php esc_html_e($ok); ?></p>
					</div>
					<?php
				}
			}
			if ( ! empty( $this->notices['error'] ) ) {
				foreach ( $this->notices['error'] as $ok ) {
					?>
					<div class="notice notice-error is-dismissible">
						<p><?php esc_html_e($ok); ?></p>
					</div>
					<?php
				}
			}
			?>

			<form method="post" action="<?php echo admin_url( 'admin.php?page=' . $this->menu_slug ); ?>">

				<table class="form-table permalink-structure">
					<tbody>
						<?php foreach ( $this->options as $key => $atts ) : ?>
							<tr>
								<th scope="row">
									<label for="<?php esc_html_e( $key ); ?>"><?php esc_html_e( $atts['label'] ); ?></label>
								</th>
								<td>
									<?php if ( ! empty( esc_html_e( $atts['top_description'] ) ) ) _('<p><em>' . esc_html_e( $atts['top_description'] ) . '</em></p>'); ?>

									<p>
									<?php if ( $atts['type'] == 'text' ) : ?>
										<input type="text" name="<?php esc_html_e( $key ); ?>" value="<?php esc_html_e( get_option( $key, $atts['default'] ) ); ?>" id="<?php echo $key; ?>">
									<?php elseif ( $atts['type'] == 'select' ) : ?>
										<?php $current = get_option( $key, $atts['default'] ); ?>
										<select name="<?php esc_html_e( $key ); ?>" id="<?php esc_html_e($key); ?>">
											<?php foreach( $atts['options'] as $option_value => $option_label ) : ?>
												<option <?php selected( $option_value, $current, true ); ?> value="<?php esc_html_e( $option_value ); ?>"> <?php esc_html_e( $option_label ); ?></option>
											<?php endforeach; ?>
										</select>
									<?php endif; ?>
									</p>

									<?php if ( ! empty( esc_html_e( $atts['description'] ) ) ) _('<p><em>' . esc_html_e( $atts['description'] ) . '</em></p>'); ?>
									
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<?php submit_button(); ?>

			</form>
		</div>

		<style>
		</style>
		<script>
		</script>
		<?php
	}

}
