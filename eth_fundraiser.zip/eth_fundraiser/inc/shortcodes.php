<?php
/**
 * This file deploys the script.
 *
 * @package shortcodes
 */

/**
 * Implants the web component script.
 */
function implant_script() {
    wp_enqueue_script( 'eth-fundraiser', plugins_url( '../assets/js/eth_fundraiser.js' , __FILE__ ), array( 'jquery' ) );
    wp_add_inline_script( 'eth-fundraiser', '
        document.addEventListener("runEthGlobal", () => {
            window.ethFundraiser.setAddress("' . esc_html( get_option( 'eth_fundraiser_address' ) ). '")
            window.ethFundraiser.setPosition("' . esc_html( get_option( 'eth_fundraiser_banner' ) ) . '")
            window.ethFundraiser.setTitleTextAndColor("' . esc_html( get_option( 'eth_fundraiser_title' ) ). '", "' . esc_html( get_option( 'eth_fundraiser_title_color' ) ) . '")
            window.ethFundraiser.setBannerBackgroundColor("' . esc_html( get_option( 'eth_fundraiser_banner_background' ) ) . '")
            window.ethFundraiser.setSVGBackgroundAndIcon("' . esc_html( get_option( 'eth_fundraiser_svg_circle' ) ) . '", "' . esc_html( get_option( 'eth_fundraiser_svg_eth_icon' ) ) . '")
            window.ethFundraiser.setBannerButtonsBackgroundAndTextColor("' . esc_html( get_option( 'eth_fundraiser_button_background' ) ) . '", "' . esc_html( get_option( 'eth_fundraiser_button_text' ) ) . '")
            window.ethFundraiser.setCloseButtonColor("' . esc_html( get_option( 'eth_fundraiser_close_btn_color' ) ) . '")
            window.ethFundraiser.setEthTextColor("' . esc_html( get_option( 'eth_fundraiser_eth_price_color' ) ) . '")
        })' );
}

/**
 * Shortcode for calling scripts
 */

add_action( 'wp_enqueue_scripts', 'implant_script' );
function eth_fundraiser_footer_scripts_shortcode() {
    wp_enqueue_scripts( 'eth-fundraiser', plugins_url( '/assets/js/eth_fundraiser.js' , __FILE__ ) );
}

/**
 *  Eth fundraiser action function.
 */
function eth_fundraiser_footer_scripts() {
    echo eth_fundraiser_footer_scripts_shortcode();
}


add_action( 'init', function() 
{
  add_action( 'wp_footer', 'eth_fundraiser_footer_scripts', 100 ); 
}, 10 );
