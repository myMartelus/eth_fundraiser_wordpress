<?php
/**
 * Plugin Name: Eth Fundraiser
 * Plugin URI: https://martelus.net/
 * Description: The Ethereum Fundraising Component facilitates the making of contributions to a community or cause by target audiences on the Ethereum blockchain.
 * Author: Martelus
 * Author URI: https://martelus.net/
 * Text Domain: eth_fundraiser
 * Version: 0.1.0
 * License: GPLv3 or later
 *
 * @package Plugin.
 */

define( 'ETH_FUNDRAISER_URL', plugin_dir_url( __FILE__ ) );
define( 'ETH_FUNDRAISER_DIR', plugin_dir_path( __FILE__ ) );
define( 'ETH_FUNDRAISER_VERSION', '0.1.0' );

include_once( 'inc/shortcodes.php' );
include_once( 'inc/class-ethfundraiserwpoptions.php' );

add_action(
	'plugins_loaded',
	function () {
		load_plugin_textdomain( 'eth_fundraiser', false, dirname( plugin_basename( __FILE__ ) ) . '/languages/' );
		if ( is_admin() ) {
			new EthFundraiserWPOptions();
		}
	}
);

add_action(
	'init',
	function () {
		if ( get_option( 'eth_fundraiser_version' ) != ETH_FUNDRAISER_VERSION ) {
			$options = new EthFundraiserWPOptions();
			update_option( 'eth_fundraiser_version', ETH_FUNDRAISER_VERSION, true );
		}
	},
	10,
	2
);
