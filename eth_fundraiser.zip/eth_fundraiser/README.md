# eth_fundraiser-wp-plugin
eth_fundraiser WP Plugin. Controls output here: https://eth_fundraiser.io/poc/alpha/

## Using Docker

This repo is ready to be used with Docker. To do so:

- Clone this repo into your machine
- Enter in the folder `/.docker`
- Run the command `docker-compose -p "eth-fundraiser-wp-plugin" build` and `docker-compose up -d`
- The system should be acessible at http://localhost:8100


## WordPress Deploy

- Update plugin version at eth_fundraiser-wp-plugin.php
- Update stable version with same tag at readme.txt
- Deploy the same tag at Github
- A Github Action will automatically deploy to WordPress Plugin Repo. The new version may take up to 6 hours to be distributed.