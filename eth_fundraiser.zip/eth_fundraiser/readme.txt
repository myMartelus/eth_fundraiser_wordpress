=== Ethereum fundraiser ===
Contributors: martelus
Donate link: https://martelus.net
Tags: crypto, fundraiser
Requires at least: 5.0
Requires PHP: 5.6
Tested up to: 6.1
Stable tag: 0.1.0
License: GPLv3 or later
License URI: http://www.gnu.org/licenses/gpl-3.0.html

== Description ==

Use our WP plugin to install Ethereum Fundraiser on your site.

<strong>What does it do?</strong>

The Ethereum Fundraising plugin facilitates the making of contributions to a community or cause by target audiences on the Ethereum blockchain.

<strong>Who is it for?</strong>

Ideal for nonprofits, educators, charities, bloggers, content creators, all who inspire and cultivate supportive communities and maintain a web presence.

== Frequently Asked Questions ==

= Can I see a demo? =

Yes. Visit Ethereum Fundraiser please demo page to see it in action. [martelus.net/main/demo](https://martelus.net/downloads/ce/configure-ce-eth/)


== Screenshots ==

1. Ethereum Fundraiser's WP admin screen.

== Installation ==

1. Install this plugin as you would any other. If you're unfamiliar with installing WordPress plugins, please read [this page from the Codex](http://codex.wordpress.org/Managing_Plugins).

2. You'll see a new top-level admin menu titled "Eth Fundraiser." Click this to manage plugin settings.

3. Configure the ERC20 address (Ethereum MainNet Address/Wallet) where you would like to receive Ethereum along with any other settings or styles you desire.

== Changelog ==

= 0.1.0 (29/01/23) =

Initial release.
